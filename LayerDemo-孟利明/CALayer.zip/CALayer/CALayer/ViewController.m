//
//  ViewController.m
//  CALayer
//
//  Created by my on 2016/12/27.
//  Copyright © 2016年 my. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (nonatomic, strong) UIView *headView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.headView];
    
    CATransform3D transform = CATransform3DIdentity;
    transform.m34 = -1/500;
    self.view.layer.sublayerTransform = transform;
    
    //设置寄宿图
    self.headView.layer.contents = (__bridge id)[UIImage imageNamed:@"headicon"].CGImage;
    
    //调整显示效果，下放两个属性同时使用无效果
//    self.headView.layer.contentsGravity = kCAGravityResizeAspectFill;
    self.headView.layer.contentsScale = [UIScreen mainScreen].scale;
    
    //设置图片的显示区域
    self.headView.layer.contentsRect = CGRectMake(0, 0, 1, 1);
    
    //设置拉伸区域
//    self.headView.layer.contentsCenter = CGRectMake(0.25, 0.25, 0.5, 0.5);
    
    //设置边框
//    self.headView.layer.borderColor = [UIColor greenColor].CGColor;
//    self.headView.layer.borderWidth = 5.f;
//    
//    //设置圆角
//    self.headView.layer.cornerRadius = 20.f;
    
    //设置阴影
//    self.headView.layer.shadowColor = [UIColor blackColor].CGColor;
//    self.headView.layer.shadowOffset = CGSizeMake(10, 10);
//    self.headView.layer.shadowRadius = 10;
//    self.headView.layer.shadowOpacity = .4;

    
    //设置裁剪，会将上方设置阴影剪裁掉
//    self.headView.layer.masksToBounds = YES;
    
    

    //另外一种设置阴影
    CAShapeLayer *shaowLayer = [CAShapeLayer layer];
    shaowLayer.shadowPath = CGPathCreateWithEllipseInRect(self.headView.bounds, NULL);
    shaowLayer.shadowRadius = 20;
    shaowLayer.shadowOpacity = .4;
    shaowLayer.shadowColor = [UIColor blackColor].CGColor;
    
    shaowLayer.bounds = self.headView.bounds;
    shaowLayer.position = self.headView.center;
    shaowLayer.zPosition = -1;
    
    [self.view.layer addSublayer:shaowLayer];
    

    
    //设置图层蒙版
    CAShapeLayer *maskLayer = [CAShapeLayer layer];
    UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:self.headView.bounds cornerRadius:self.headView.bounds.size.width/2];
    maskLayer.path = maskPath.CGPath;
    self.headView.layer.mask = maskLayer;
    
    //旋转
    CATransform3D shaowTrans = CATransform3DIdentity;
    shaowTrans = CATransform3DRotate(shaowTrans, M_PI/3, 1, 0, 0);
    shaowTrans = CATransform3DTranslate(shaowTrans, 0, -200, 0);
    self.headView.layer.transform = shaowTrans;

    shaowTrans = CATransform3DTranslate(shaowTrans, 0, 0, -30);
    shaowLayer.transform = shaowTrans;

}



- (UIView *)headView {
    if (!_headView) {
        _headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, 300)];
        _headView.center = self.view.center;
        
    }
    return _headView;
}


@end
