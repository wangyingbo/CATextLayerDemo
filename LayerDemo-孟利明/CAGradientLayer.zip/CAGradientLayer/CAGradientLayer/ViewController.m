//
//  ViewController.m
//  CAGradientLayer
//
//  Created by my on 2016/12/29.
//  Copyright © 2016年 my. All rights reserved.
//

#import "ViewController.h"

#define LineOrCircle 1 //1直线  2圆环 3文字

@interface ViewController ()


@property (nonatomic, strong) CAGradientLayer *gradient;
@property (nonatomic, strong) CADisplayLink *displaylink;


@property (nonatomic, strong) CAShapeLayer *maskLayer;
@property (nonatomic, assign) CGFloat progress;

@property (nonatomic, strong) UILabel *textLabel;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
#if LineOrCircle == 1
    //line
    [self line];
#elif LineOrCircle == 2
    //circle
    [self circle];
#elif LineOrCircle == 3
    //text
    [self text];
#endif
    _displaylink = [CADisplayLink displayLinkWithTarget:self
                                               selector:@selector(colorsAnimation)];
    [_displaylink addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSDefaultRunLoopMode];
}


- (void)circle {
    _gradient = [self gradientWithBounds:CGRectMake(0, 0, 300, 300)
                              startPoint:CGPointMake(0, 0)
                                endPoint:CGPointMake(1, 1)];
    _gradient.colors = [self colors];
    [self.view.layer addSublayer:_gradient];
    
    
    CGFloat lineWidth = 2;
    
    _maskLayer = [CAShapeLayer layer];
    _maskLayer.path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(lineWidth/2, lineWidth/2, 300 - lineWidth, 300 - lineWidth)].CGPath;
    _maskLayer.fillColor = [UIColor clearColor].CGColor;
    _maskLayer.strokeColor = [UIColor blackColor].CGColor;
    _maskLayer.lineWidth = lineWidth;
    _maskLayer.strokeStart = 0;
    _maskLayer.strokeEnd = 0;
    _gradient.mask = _maskLayer;
}

- (void)line {
    _gradient = [self gradientWithBounds:CGRectMake(0, 0, self.view.frame.size.width, 2)
                              startPoint:CGPointMake(0, 0)
                                endPoint:CGPointMake(1, 0)];
    _gradient.colors = [self colors];
    [self.view.layer addSublayer:_gradient];
    
    
    _maskLayer = [CAShapeLayer layer];
    _maskLayer.frame = CGRectMake(0, 0, 0, 2);
    _maskLayer.backgroundColor = [UIColor blackColor].CGColor;
    _gradient.mask = _maskLayer;
}

- (void)text {
    _gradient = [self gradientWithBounds:CGRectMake(0, 0, 300, 80)
                              startPoint:CGPointMake(0, 0)
                                endPoint:CGPointMake(1, 0)];
    _gradient.colors = [self colors];
    [self.view.layer addSublayer:_gradient];
    
    _textLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 300, 80)];
    _textLabel.text = @"走得慢，还好没停下";
    _textLabel.textAlignment = NSTextAlignmentCenter;
    _textLabel.font = [UIFont systemFontOfSize:20];
    _gradient.mask = _textLabel.layer;
}

#pragma mark - 渐变色
- (CAGradientLayer *)gradientWithBounds:(CGRect)bounds
                             startPoint:(CGPoint)start
                               endPoint:(CGPoint)end {
    CAGradientLayer *layer = [CAGradientLayer layer];
    layer.bounds = bounds;
    layer.position = self.view.center;
    layer.startPoint = start;
    layer.endPoint = end;
    return layer;
}


#pragma mark - 色谱
- (NSArray *)colors {
    NSMutableArray *colors = [NSMutableArray array];
    for (NSInteger hue = 0; hue <= 360; hue += 3) {
        
        UIColor *color;
        color = [UIColor colorWithHue:hue / 360.0
                           saturation:1.0
                           brightness:1.0
                                alpha:1.0];
        [colors addObject:(id)[color CGColor]];
    }
    return colors;
}

- (void)colorsAnimation {
    NSMutableArray *arr = [_gradient.colors mutableCopy];
    id lastColor = [arr lastObject];
    [arr removeObject:lastColor];
    [arr insertObject:lastColor atIndex:0];
    _gradient.colors = arr;
    
    
    
    _progress += 0.1/60;
    _progress = MIN(1, _progress);

#if LineOrCircle == 1
    //line
    CGRect maskRect = _maskLayer.bounds;
    maskRect.size.width = self.view.frame.size.width * _progress;
    _maskLayer.frame = maskRect;
#elif LineOrCircle == 2
    //circle
    _maskLayer.strokeStart = 0;
    _maskLayer.strokeEnd = _progress;
#endif
    
    CABasicAnimation *animation = [CABasicAnimation animation];
    animation.keyPath = @"colors";
    animation.toValue = arr;
    animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
    animation.duration = 1/60.0;
    [animation setRemovedOnCompletion:YES];
    [animation setFillMode:kCAFillModeForwards];
    [_gradient addAnimation:animation forKey:nil];
}


- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    if (_progress < .5) {
        _progress = .5;
    }
    
    if (_progress >.7) {
        _progress = 1;
    }
}


@end
